import { Component, OnInit } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { FragmentService } from '../../services/fragment.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router } from '@angular/router';

declare var WaveSurfer: any;

@Component({
  selector: 'app-fragmentifier',
  templateUrl: './fragmentifier.component.html',
  styleUrls: ['./fragmentifier.component.css'],
})
export class FragmentifierComponent implements OnInit {

  wavesurfer: any;
  slider: any;
  canvas: any;

  file: File;
  uploaded: Boolean = false;
  fileUploadId: String;
  start: Number;
  end: Number;
  isTagging: Boolean = false;
  tags: Array<any> = [];
  youtube: String = "https://www.youtube.com/watch?v=9-yUbFi7VUY";

  constructor(private fragmentService: FragmentService, private flashMessagesService: FlashMessagesService, private router: Router) { }

  ngOnInit() {
    var me = this;
    this.wavesurfer = WaveSurfer.create({
      container: '#waveform',
      waveColor: '#2b3e50',
      progressColor: 'white'
    });

    this.slider = document.querySelector('#slider');

    this.slider.oninput = function () {
      var zoomLevel = Number(me.slider.value);
      me.wavesurfer.zoom(zoomLevel);
    };

    //this.wavesurfer.load('http://ia902606.us.archive.org/35/items/shortpoetry_047_librivox/song_cjrg_teasdale_64kb.mp3');

  }

  another() {
    this.file = null;
    this.uploaded = false;
    this.start = null;
    this.end = null;
    this.isTagging = false;
    this.tags = [];
    this.fileUploadId = null;
  }

  uploadYouTube() {
    // this.fragmentService.uploadYouTube({url: this.youtube}, (err, res) => {
    //   debugger;
    // });

    this.fragmentService.uploadYouTube({ url: this.youtube }).subscribe(data => {
      if (data.success) {
        this.flashMessagesService.show('Whoa! It worked?', {
          cssClass: 'alert-success',
          timeout: 5000
        });
        this.wavesurfer.load("http://zunz.io:3000/" + data.filepath);
        this.fileUploadId = data.id;
        this.uploaded = true;
      }
      else {
        this.flashMessagesService.show(data.error, {
          cssClass: 'alert-danger',
          timeout: 5000
        });
      }
    });
  }

  uploadFile() {
    //
    let fragment = {
      file: this.file,
    }

    this.fragmentService.uploadFile(fragment, (err, res) => {
      console.log(err, res);
      if (err) {
        this.flashMessagesService.show(err, {
          cssClass: 'alert-danger',
          timeout: 5000
        });
      }
      if (!err) {
        this.wavesurfer.load("http://zunz.io:3000/" + res.filepath);
        this.fileUploadId = res.id;
        this.uploaded = true;
      }
    });
  }

  fileChange(event) {
    let fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      this.file = fileList[0];
    }
  }

  play() {
    this.wavesurfer.play();
  }

  pause() {
    this.wavesurfer.pause();
  }

  tagStart() {
    if (!this.isTagging) {
      this.start = this.wavesurfer.backend.getCurrentTime();
      this.isTagging = true;
    }
  }

  tagEnd() {
    if (this.isTagging) {
      this.end = this.wavesurfer.backend.getCurrentTime();
      this.isTagging = false;

      let tag = {
        start: this.start,
        end: this.end,
        word: "",
      }

      this.tags.push(tag);
    }

  }

  removeTag(tag) {
    this.tags.splice(this.tags.indexOf(tag), 1);
  }

  playTag(tag) {
    var start = tag.start;
    var end = tag.end;
    this.wavesurfer.play(start, end);
    // this.wavesurfer.play(0, 0.5);
  }

  submit() {
    let fragment = {
      fileUploadId: this.fileUploadId,
      tags: this.tags,
    }

    this.fragmentService.submit(fragment).subscribe(data => {
      if (data.success) {
        this.flashMessagesService.show('Fragment is submitted for review! Thank you!', {
          cssClass: 'alert-success',
          timeout: 5000
        });

        this.another();
      }
      else {
        this.flashMessagesService.show(data.error, {
          cssClass: 'alert-danger',
          timeout: 5000
        });
      }
    });

  }
}
