import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { AuthService } from '../services/auth.service';

@Injectable()
export class FragmentService {

  constructor(private http: Http, private authService: AuthService) {

  }

  uploadYouTube(url) {

    this.authService.loadToken();
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', this.authService.authToken);

    return this.http.post('http://zunz.io:3000/fragments/uploadyoutube', url, {headers: headers}).map(res => res.json());
  }

  uploadFile(fragment, callback) {

    let formData: FormData = new FormData();
    let xhr = new XMLHttpRequest();

    formData.append('file', fragment.file);
    formData.append('sentence', fragment.sentence);

    xhr.onreadystatechange = function () {
      if (xhr.readyState == 4) {

        if (xhr.status == 200) {

          //console.log(JSON.parse(xhr.response));
          // resolve(JSON.parse(xhr.response));
          callback(null, JSON.parse(xhr.response));
        }
        else {
          // reject(xhr.response);
          //console.log(JSON.parse(xhr.response));
          callback(false, JSON.parse(xhr.response));
        }
      }
    }
    xhr.open("POST", 'http://zunz.io:3000/fragments/uploadfile', true);
    this.authService.loadToken();
    xhr.setRequestHeader('Authorization', this.authService.authToken);
    xhr.send(formData);

    // return this.http.post('http://localhost:3000/fragments/upload', formData, {headers: headers}).map(res => res.json());
  }

  submit(fragment) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    this.authService.loadToken();
    headers.append('Authorization', this.authService.authToken);

    return this.http.post('http://zunz.io:3000/fragments/submit', fragment, { headers: headers }).map(res => res.json());
  }

  tts(text) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    this.authService.loadToken();
    headers.append('Authorization', this.authService.authToken);
    
    return this.http.post('http://zunz.io:3000/fragments/tts', text, { headers: headers }).map(res => res.json());
  }
}
